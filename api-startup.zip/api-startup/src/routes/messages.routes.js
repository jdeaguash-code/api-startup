const express = require('express');
const router = express.Router();
const Message = require('../models/Message');
const User = require('../models/User');

// GET - Leer todos los mensajes (con datos del usuario)
router.get('/', async (req, res) => {
  try {
    const messages = await Message.find().populate('usuario', 'nombre email');
    res.json(messages);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// GET - Leer un mensaje por ID
router.get('/:id', async (req, res) => {
  try {
    const message = await Message.findById(req.params.id).populate('usuario', 'nombre email');
    if (!message) return res.status(404).json({ message: 'Mensaje no encontrado' });
    res.json(message);
  } catch (error) {
    res.status(400).json({ message: 'ID inválido' });
  }
});

// POST - Crear mensaje
router.post('/', async (req, res) => {
  try {
    const { usuario, contenido } = req.body;

    const existe = await User.findById(usuario);
    if (!existe) return res.status(404).json({ message: 'El usuario no existe' });

    const message = new Message({ usuario, contenido });
    await message.save();
    res.status(201).json({ message: 'Mensaje creado', id: message._id });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// PUT - Editar mensaje (solo el contenido)
router.put('/:id', async (req, res) => {
  try {
    const message = await Message.findByIdAndUpdate(
      req.params.id,
      { contenido: req.body.contenido },
      { new: true, runValidators: true }
    );
    if (!message) return res.status(404).json({ message: 'Mensaje no encontrado' });
    res.json({ message: 'Mensaje actualizado', data: message });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// DELETE - Borrar mensaje
router.delete('/:id', async (req, res) => {
  try {
    const message = await Message.findByIdAndDelete(req.params.id);
    if (!message) return res.status(404).json({ message: 'Mensaje no encontrado' });
    res.json({ message: 'Mensaje eliminado' });
  } catch (error) {
    res.status(400).json({ message: 'ID inválido' });
  }
});

module.exports = router;