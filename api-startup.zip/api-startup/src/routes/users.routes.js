const express = require('express');
const router = express.Router();
const User = require('../models/User');

// GET - Leer todos los usuarios
router.get('/', async (req, res) => {
  try {
    const users = await User.find().select('-password');
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// GET - Leer un usuario por ID
router.get('/:id', async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-password');
    if (!user) return res.status(404).json({ message: 'Usuario no encontrado' });
    res.json(user);
  } catch (error) {
    res.status(400).json({ message: 'ID inválido' });
  }
});

// POST - Crear usuario
router.post('/', async (req, res) => {
  try {
    const { nombre, email, password } = req.body;
    const user = new User({ nombre, email, password });
    await user.save();
    res.status(201).json({ message: 'Usuario creado', id: user._id });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// PUT - Editar usuario
router.put('/:id', async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    }).select('-password');
    if (!user) return res.status(404).json({ message: 'Usuario no encontrado' });
    res.json({ message: 'Usuario actualizado', user });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// DELETE - Borrar usuario
router.delete('/:id', async (req, res) => {
  try {
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user) return res.status(404).json({ message: 'Usuario no encontrado' });
    res.json({ message: 'Usuario eliminado' });
  } catch (error) {
    res.status(400).json({ message: 'ID inválido' });
  }
});

module.exports = router;